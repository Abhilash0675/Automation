package Tasks;

public class Task2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		Object []obj = new Object[4];
		
		obj[0]="mukesh";
		obj[1]="Testing";
		obj[2]="mukesh@gmail.com";
		obj[3]=1;
		
		for(int i=0;i<obj.length;i++) {
			
		
			System.out.println(obj[i]);
		}
		
		
		System.out.println("************");
		
		
		Object[] obj1 = new Object[4];
		
		obj1[0]="Hitesh";
		obj1[1]="Dev";
		obj1[2]="mukesh@gmail.com";
		obj[3]=2;
		
		for(int j=0;j<obj1.length;j++) {
			System.out.println(obj[j]);
			
		}
		
		
		System.out.println("************");
		
		
		Object[] obj2 = new Object[4];
		
		obj2[0]="Mukesh";
		obj2[1]="Devops";
		obj2[2]="mukesh@gmail.com";
		obj2[3]=3;
		
		
		for(int k=0;k<obj2.length;k++) {
			System.out.println(obj2[k]);
			
		}
		
		

	}

}
