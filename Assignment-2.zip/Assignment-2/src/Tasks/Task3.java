package Tasks;

import java.util.Scanner;

public class Task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String name1,name2,name3;
		String email1,email2,email3;
		int phone;
		String address;
		String status;
		String student; 
		
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("Please enter number of student : ");
		student =sc.nextLine();
		
		System.out.println("Please enter name : ");
		name1=sc.nextLine();
		
		System.out.println("Please enter Email: ");
		email1=sc.nextLine();
		
		
		System.out.println("Please enter name: ");
		name2=sc.nextLine();
		
		System.out.println("Please enter Email: ");
		email2=sc.nextLine();
		
		System.out.println("Please enter name: ");
		name3=sc.nextLine();
		
		System.out.println("Please enter Email: ");
		email3=sc.nextLine();
		
		
		
		System.out.println("Please enter which student deatils are you looking for: ");
		student =sc.nextLine();
		
		System.out.println(name1);
		System.out.println(email1);
		
		System.out.println("Please enter which student deatils are you looking for: ");
		student =sc.nextLine();
		
		System.out.println(name2);
		System.out.println(email2);
		
		System.out.println("Please enter which student deatils are you looking for: ");
		student =sc.nextLine();
		
		System.out.println(name3);
		System.out.println(email3);
		
	
		
	
		
		
		
		

		

	}

}
