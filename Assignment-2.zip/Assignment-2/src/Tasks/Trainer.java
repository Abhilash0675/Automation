package Tasks;

public class Trainer {
	
	String name;
	String department;
	String email;
	int id;
	
	public Trainer(String name,String Department ,String email,int id ) {
		this.name=name;
		this.department=Department;
		this.email=email;
		this.id = id;
	}
	
	public void Selenium() {
		System.out.println("Tranier1 Can teach Selenium ");
	}
	
	public void WebDevlopment() {
		System.out.println("Tranier2 Can teach WebDevlopment ");
	}
	
	public void Devops() {
		System.out.println("Tranier3 Can teach Devops  ");
	}
	
	
	
	public static void main(String[] args) {
		
		
		Trainer trainer1 = new  Trainer("mukesh", "testing", "mukesh@gmail.com", 1);
				
		trainer1.Selenium();
		
		Trainer trainer2 = new  Trainer("Hitesh", "Dev", "mukesh@gmail.com", 2);
		
		trainer2.WebDevlopment();
		
		Trainer trainer3 = new  Trainer("Mukesh", "Devops", "mukesh@gmail.com", 3);
		
		trainer3.Devops();
		
		

	}

}
