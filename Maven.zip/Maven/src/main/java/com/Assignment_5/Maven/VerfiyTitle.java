package com.Assignment_5.Maven;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class VerfiyTitle {
	
	public static WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
WebDriverManager.chromedriver().setup();
		
		driver = new ChromeDriver();
		
        String url = " https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		
		driver.get(url);
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		String actualtext = driver.getTitle();
		
		System.out.println(actualtext);
		
		String Expectedtext = "HRM";
		
		if(actualtext.equalsIgnoreCase(Expectedtext)) {
			
			System.out.println("title matched");
			
		}else {
			System.out.println("title doesnt matched");
		}
			
		driver.quit();

	}

}
