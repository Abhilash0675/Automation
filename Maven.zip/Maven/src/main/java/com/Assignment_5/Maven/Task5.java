package com.Assignment_5.Maven;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Task5 {
	
	public static WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		WebDriverManager.chromedriver().setup();
		
		driver =  new ChromeDriver();
		
		String url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		driver.get(url);
		
	
		WebElement footericons = driver.findElement(By.xpath("//div[@class='orangehrm-login-footer-sm']"));
		
		
		List<WebElement> links = footericons.findElements(By.xpath("//a[contains(@href,'')]"));
		
		for( WebElement s : links) {
		
			
			if(s.getText().contains("youtube")) {
				
				
				System.out.println("looking for youtube");
				
			}
			}
		
	
		
		driver.quit();
			
		}
		

	}


