package com.Assignment_5.Maven;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Task3 {
	
	public static WebDriver driver;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		WebDriverManager.chromedriver().setup();
		
		driver = new ChromeDriver();
		
		
		String url = "https://opensource-demo.orangehrmlive.com/web/index.php/auth/login";
		
		driver.manage().timeouts().implicitlyWait(3, TimeUnit.SECONDS);
		
		driver.get(url);
		
		WebElement FooterImages = driver.findElement(By.xpath("//div[@class='orangehrm-login-footer-sm']"));
		
		
	 List<WebElement> links = 	FooterImages.findElements(By.tagName("a"));
	
	int count = links.size();
	
	if(count>=links.size()) {
		
		System.out.println("Website has social media icons has 4 ");

	
		}else {
			
			System.out.println("Website doesnt  ha social media icons has 4");
		}

		
	
	driver.close();

	}
}


