import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Task1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List <String> list = new ArrayList<>();
		
		list.add("java");
		list.add("selenium");
		list.add("TestNg");
		list.add("git");
		list.add("github");
		
		
		Collections.reverse(list);
		
		System.out.println(list);

	}

}
