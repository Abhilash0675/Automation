import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Task5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list = new ArrayList<>(Arrays.asList(11,22,33));
		
		System.out.println(list);
		
		
		List<Integer> list2 = new ArrayList<Integer>(Arrays.asList(9,19,29));
		
		list.addAll(list2);
		
		System.out.println(list);
		
List<Integer> list3 = new ArrayList<Integer>(Arrays.asList(7,17,27));
		
		list.addAll(list3);
		
		System.out.println(list);
		
		

	}

}
