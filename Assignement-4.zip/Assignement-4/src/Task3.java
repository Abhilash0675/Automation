import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Task3 {
	
	/*
	 * Write a Program that will remove Duplicates Values from list 
	 * 
	 * Input- Java, TestNg, Maven, java.
	 * Output - Java, TestNg, Maven.
	 * 
	 * 
	 * 
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		List<String> list = new ArrayList<>();
		list.add("Java");
		list.add("TestNg");
		list.add("Maven");
		list.add("Java");
		
		System.out.println(list);

		Set<String> set = new HashSet<>(list);
		
		System.out.println(set);
	}

}
