import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Task2 {
	
	/*
	 * Write a program which will accept List of String and produce a another List of String of
	 *  which will have only values which starts with git.
	 *  
	 *  Input- Git, Github, GitLab, GitBash,Selenium,Java, Maven.
	 *  Output- Git, Github,Gitlab,Git
	 * 
	 * 
	 * 
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		List<String> list = new ArrayList<>(Arrays.asList("Git","Github","GitLab","GitBash","Selenium","Java","Maven"));
		
		//System.out.println(list);
		//System.out.println(list.isEmpty());
		list.clear();
		
		
		List<String> list2 = new ArrayList<>(Arrays.asList("Git","Github","Gitlab","GitBash"));
		
		list.addAll(list2);
		
		System.out.println(list);
		

	}

}
