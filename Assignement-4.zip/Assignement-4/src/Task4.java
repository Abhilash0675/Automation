import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list = new ArrayList<>(Arrays.asList(10,45,90,45,23,90,44));
		
		System.out.println(list.get(1));
		
		System.out.println(list.get(5));
		
		
	
	}

}
