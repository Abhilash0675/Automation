package task;

import java.util.ArrayList;
import java.util.List;

public class Task7 {
	
	/*
	 * Write a program which will display true if list contains MObile else prints False
	 * 
	 * List - WebAutomation, API Automation, Mobile Automation.
	 * output - Ture.
	 * 
	 * 
	 * 
	 */

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List <String> list  = new ArrayList<String>();
		list.add("web   Automation");
		list.add("Api   Automation");
		list.add("Mobile Automation");
		
		for( String w:list) {
			
			if(w.contains("Mobile Automation")) {
				
				System.out.println(true);
				
			}else 
			{
				System.out.println(false);
			}
			
		}
		
		
		


	}

}
