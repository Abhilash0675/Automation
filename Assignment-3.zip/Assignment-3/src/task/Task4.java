package task;

import java.util.ArrayList;
import java.util.List;


// // Write a Program which will print sum of all numbers which is stored in list.

public class Task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list = new ArrayList<Integer>();
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		int sum =0;
		
		for(int i=0; i<list.size();i++) 
			
		sum += list.get(i);
		
		System.out.println("sum of number :" + sum);
			
		

	}

}
