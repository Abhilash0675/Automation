package task;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

//Write a Program which can store List of integer values and print all using for Iterator.

public class task3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(12);
		list.add(14);
		list.add(16);
		list.add(18);
		list.add(30);
		
	Iterator<Integer> itr = 	list.iterator();
		
		while(itr.hasNext()) {
			
			Integer i = itr.next();
			
			System.out.println(i);
			
		}
	}

}
