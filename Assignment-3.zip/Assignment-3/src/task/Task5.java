package task;

import java.util.ArrayList;
import java.util.List;

public class Task5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		// Write a program which will pick the values from array and store them list. 
		
		int arr [] = {1,5,6,7,6,5};
		
		List<Integer> list = new ArrayList<>();
		
		for(int i :arr) {
			list.add(i);
			
			
		}
		
		System.out.println("Arraylist"+ list);
		


	}

}
