package task;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/*  
 * 
 * Create a list of numbers 33,44,55,66,77,88
 * - Remove Second element from list using index.
 * - Add 90 at index 3 
 * - Get the length of list.
 * - print all values from list using any values.
 * 
 * - Convert list to array.
 * 
 */

public class Task6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		List<Integer> list = new ArrayList <>();
		
		list.add(33);
		list.add(44);
		list.add(55);
		list.add(66);
		list.add(77);
		list.add(88);
		
		list.remove(2);
		
		
		
	
		
	    list.add(3, 90);
		
		System.out.println("Size of the list :"  + list.size());
		
		for(Integer numbers: list) {
			
			System.out.println(numbers);
			
			
		}
		
		List<Integer> list2 = new ArrayList <>();
		
		list2.add(77);
		list2.add(78);
		list2.add(79);
		list2.add(76);
		
		
		
		Integer [] arr = new Integer [list2.size()];
		arr = list2.toArray(arr);
		
		for(Integer num:arr) {
			System.out.println(num);
		
		

	}

}
}
