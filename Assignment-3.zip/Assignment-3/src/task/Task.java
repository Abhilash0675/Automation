package task;

import java.util.ArrayList;
import java.util.List;

public class Task {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 ArrayList<Integer> list2 = new ArrayList <Integer>();
		
		list2.add(77);
		list2.add(78);
		list2.add(79);
		list2.add(76);
		
		
		
		Integer [] arr = new Integer [list2.size()];
	
		list2.toArray(arr);
		
		for(Integer i : arr) {
			
			System.out.println(i);
			
		}
			
		

	}

}
