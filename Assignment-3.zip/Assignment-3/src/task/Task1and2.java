package task;

import java.util.ArrayList;
import java.util.List;



// Write a Program which can store List of integer values and print all using for loop and For Each loop.
public class Task1and2 {
	
	public static void main(String[]args) {
		
		List<Integer> list = new ArrayList<Integer>();
		
		list.add(20);
		list.add(30);
		list.add(40);
		list.add(50);
		list.add(60);
		list.add(70);
		
	/*	for(int num:list) {
			
			System.out.println(num);
			
		}
		
		*/
		
		for(int i= 0;i<list.size();i++) {
			System.out.println(list.get(i));
			
		}
		
		
	}

	

	
	

}
