
public class Task4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int number =200;
		
		System.out.println("Even Numbers from 1 to" + number +" :");
		
		for(int i =1; i<number; i++) {
			
			
			if(i%2==0) {
				
				System.out.println(i+" ");
				
			}
			
		}

	}

}
