
public class task1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		int a =10;
		int b=20;
		int c;
		
		System.out.println("BeforeSwapping"+ a +" "+ b);
		
		c=a;
		a=b;
		b=c;
		
		System.out.println("AfterSwapping"+ a+ " "+b);
		
	

	}

}
