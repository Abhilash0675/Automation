
public class Task8 {

	public static void main(String[] args) {
		
		int a = 78;
	int b= 12;
	int c= 89;
		int d = 55;
		int e = 35;
		int num = 80;

	
		if(a<num&&c>num) {
	System.out.println("print the values which are above "+a +" "+c);
			
		
	}else if(b<num&&c>num) {
		System.out.println("print the values which are above "+b +" "+c);
		
		}else if (c<num&&d>num) {
			System.out.println("print the values which are above "+c+" "+d);
	}
		
		
		
		

	}

}
