
public class task9 {

	public static void main(String[] args) {
		
		int num = 4;
		
		switch(num) {
		
		
		case 1:
			System.out.println("12");
			break;
			
			
		case 2:
			System.out.println("34");
			break;
			
		case 3:
			System.out.println("66");
			break;
			
		case 4:
			System.out.println("85");
			break;
			
		case 5:
			System.out.println("900");
			break;
			
			default:
				System.out.println("print all the numbers");
				
			
		
		}

	}

}
