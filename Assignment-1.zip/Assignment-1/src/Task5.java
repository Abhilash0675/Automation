
public class Task5 {

	public static void main(String[] args) {
		
		int number =50;
		
		System.out.println("Odd numbers"+ number+ " : ");
		
		for(int i=1; i<number ;i++) {
			
			if(i%2!=0) {
				
				System.out.println(i);
			}
		}

	}

}
