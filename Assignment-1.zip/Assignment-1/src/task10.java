
public class task10 {

	public static void main(String[] args) {
		
		int words = 3;
		
		switch (words) {
		
		case 1:
			System.out.println("java");
			break;
		case 2:
			System.out.println("javascript");
			break;
		case 3:
			System.out.println("selenium");
			break;
		case 4:
			System.out.println("python");
			break;
			
		case 5:
			System.out.println("mukesh");
			break;
			
			default :
			{
				System.out.println("Print all words");
			}
		
		}
		
			
		
	}

}
